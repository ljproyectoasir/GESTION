
 
<?php 

	// isset: si no esta definida la variable devuelve false
   if (isset($_POST["color"])) 
		{	
		$datos = $_POST["color"]; 
		setcookie("colorfondo", $datos, time()+10);  
		}
	  else
		  $datos="white";
	 
	switch ($datos) 
	{
    case "green":
		$datos1="verde";
        break;
    case "red":
        $datos1="rojo";
        break;
    case "blue":
        $datos1="azul";
        break;
	default:
		$datos1="blanco";
	}
?>
<html>
<head>
<title>Page title</title>
</head>
<?php
	echo "<body bgcolor=$datos>";
	echo "<center><h1> El color de fondo es: $datos1</h2></center>";     
    ?> </body></html>